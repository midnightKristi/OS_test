/*
* Original source: https://www.concretepage.com/java/example_managementfactory_java
*/

import java.lang.management.ClassLoadingMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.ThreadMXBean;
import java.util.List;

public class cpuMonitor {

    // This helper begins the cpuMonitor.
    //public static void startMonitor(){ main(true); }

    // This helper stops the cpuMonitor
    //public static void stopMonitor(){ main(false); }

    public static void main(String[] args){
        Thread th = new UserThread();
        Runtime.getRuntime().addShutdownHook(th);
    }
    static class UserThread extends Thread {
        public void run() {
            // Using getThreadMXBean
            System.out.println("Result of getThreadMXBean ");
            ThreadMXBean thMxB = ManagementFactory.getThreadMXBean();
            System.out.println(("\tCurrent thread count:"+ thMxB.getThreadCount()));
            //using getMemoryPoolMXBeans
            System.out.println("Result of getMemoryPoolMXBeans ");
            List<MemoryPoolMXBean> mpmxList = ManagementFactory.getMemoryPoolMXBeans();
            for (MemoryPoolMXBean pl : mpmxList) {
                MemoryUsage peak = pl.getPeakUsage();
                System.out.println("\tPeak Memory Usage " + peak.getUsed());
            }
            // Using getClassLoadingMXBean
            System.out.println("Result of getClassLoadingMXBean ");
            ClassLoadingMXBean clmxB= ManagementFactory.getClassLoadingMXBean();
            System.out.println("\tClass Loading " + clmxB.getTotalLoadedClassCount());
        }
    }
}