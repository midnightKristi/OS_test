/*
* This program calls the sorting test programs which test the following three sorting algorithms: insertion sort, shell sort, and quick sort.
* And this program calls a program that takes an array of randomly generated numbers and makes is almost sorted.
* Created with some guidance from: https://www.ibm.com/docs/en/i/7.2?topic=javalangruntimeexec-example-calling-another-java-program
*/
import java.io.*;
import java.sql.Timestamp;
import java.util.Date;

public class SortingTest {

	// This is a helper function to convert the date into a timestamp
	public static void getTimestamp(){
		Date date = new Date();
		Timestamp ts = new Timestamp(date.getTime());
		System.out.println(ts);
	}
	
	public static void  main(String[] args) throws IOException {
		// start the CPU monitor class
		//cpuMonitor.startMonitor();

		//Instantiating the File class
		File file = new File("D:\\results.txt");
		//Instantiating the PrintStream class
		PrintStream stream = new PrintStream(file);
		System.out.println("Results will be saved to "+file.getAbsolutePath());
		System.setOut(stream);

		////////////////////////////////////
		// call and run AlmostSorted.java
		// takes the randomly generated
		// number file and nearly sorts it.
		///////////////////////////////////
		AlmostSorted.main();

		/////////////////////////////////////
		// call and run insertion sort test
		////////////////////////////////////
		getTimestamp();
		InsertionTests.testUnsorted();
		getTimestamp();
		InsertionTests.testAlmostSorted();
		getTimestamp();
		System.out.println("------------------------------------------");

		/////////////////////////////////
		// call and run shell sort test
		/////////////////////////////////
		getTimestamp();
		ShellTests.testUnsorted();
		getTimestamp();
		ShellTests.testAlmostSorted();
		getTimestamp();
		System.out.println("------------------------------------------");

		/////////////////////////////////
		// call and run quick sort test
		////////////////////////////////
		getTimestamp();
		QuickTests.testUnsorted();
		getTimestamp();
		QuickTests.testAlmostSorted();
		getTimestamp();

		System.out.println("\nDone.");

		// stop the CPU monitor class
		///cpuMonitor.stopMonitor();

	} // end main

} // end SortingTest
